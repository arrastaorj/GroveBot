module.exports = {
    clientId: "1053482665942196224",
    clientPrefix: "!",
    developers: ["424244967893106699"],
    nodes: [
        {

            host: "lavagrove.squareweb.app",
            port: 443,
            name: 'GroveLavaLink',
            password: "7856",
            secure: true

        },
    ]
}