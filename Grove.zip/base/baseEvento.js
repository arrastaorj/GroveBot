const client = require('../../index')
const discord = require("discord.js")

client.on("", async () => {

})