module.exports = {

    language: "pt", //en, tr, nl, pt, fr, ar, zh_TW, it, ja

}